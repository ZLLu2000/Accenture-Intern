import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['axes.unicode_minus']=False #显示负号
plt.rcParams['font.sans-serif']=['SimHei'] #中文显示

data = pd.read_csv(r"US_Crime_Rates_1960_2014.csv")#读取数据文件
data = data[(data["Year"]>=1991)]#取1991以后数据
Population=0
for k in data.columns[1:]:#遍历各犯罪字段
    x = data["Year"]
    y = data[k]
    slope,intercept,r,p,std_err=stats.linregress(x,y)#回归拟合，取模型参数
    def myfunc(x):#回归函数
        return slope*x+intercept
    mymodel = list(map(myfunc,x))
    plt.scatter(x,y)#绘制散点图
    plt.plot(x,mymodel)#回归线
    plt.title("{}线性回归".format(k))#标题
    plt.xlabel("年份")#x轴标题
    plt.grid()#网格线
    plt.show()#绘图
    num = int(myfunc(2019))#预测值
    if k == "Population":
        print("2019年{}预测值：".format(k),num)
        Population = num#2019人数预测
    else:
        print("2019年Population预测值：{}".format(Population))#2019人数预测
        print("2019年{}预测值：".format(k),num)#预测值
        print("2019年{}犯罪率预测值：{}%".format(k,round(100*num/Population,4)))#计算犯罪率
        
