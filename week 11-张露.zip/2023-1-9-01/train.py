import os, csv
import pandas as pd
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, optimizers, losses
from keras.callbacks import TensorBoard
from sklearn import preprocessing

def load_csv(root, csv_name):
    images, labels = [], []
    with open(os.path.join(root, csv_name), 'r', encoding='utf8') as f:
        reader = csv.reader(f)
        for row in reader:
            if row[1] == 'id':
                continue
            label = int(row[1])
            data = list(map(float, row[2:]))
            images.append(data)
            labels.append(label)
    assert len(images) == len(labels)
    return images, labels


def load_csv_normalize(root, csv_name):
    pa_csv = pd.read_csv(os.path.join(root, csv_name))
    for item in pa_csv.columns.values[1:]:
        if item == ' Net Income Flag':
            continue
        pa_csv[item] = (pa_csv[item] - pa_csv[item].min()) / (pa_csv[item].max() - pa_csv[item].min())
    pa_csv.to_csv("temp.csv", mode='a', header=False)


def load_data(images, labels, mode='train'):
    if mode == 'train':  # 60%
        images = images[:int(0.8 * len(images))]
        labels = labels[:int(0.8 * len(labels))]
    elif mode == 'val':  # 20% = 80%->100%
        images = images[int(0.8 * len(images)):]
        labels = labels[int(0.8 * len(labels)):]
    else:
        pass
    return images, labels


def preprocess(x, y):
    x = tf.convert_to_tensor([x])
    x = tf.cast(x, dtype=tf.float32)
    y = tf.convert_to_tensor([y])
    y = tf.cast(y, dtype=tf.int8)
    y = tf.one_hot(y, depth=2)
    return x, y

root = "/home/zhangzifan/MaintoCode/2023-1-9-01"
csv_name = "train.csv"
model_name = "final.h5"
batch_size = 128
epoch = 100
load_csv_normalize(root, csv_name)
images_all, label_all = load_csv(root, 'temp.csv')
train_images, train_labels = load_data(images_all, label_all, mode="train")
val_images, val_labels = load_data(images_all, label_all, mode="val")


db_train = tf.data.Dataset.from_tensor_slices((train_images, train_labels))
db_train = db_train.map(preprocess).batch(batch_size)
db_val = tf.data.Dataset.from_tensor_slices((val_images, val_labels))
db_val = db_val.map(preprocess).batch(batch_size)



# net = keras.applications.VGG16(weights='imagenet', include_top=False, pooling='max')
# net.trainable = False
newnet = keras.Sequential([
    # net,
    layers.Dense(64),
    layers.Dense(128),
    layers.Dense(256),
    layers.Dense(128),
    layers.Dense(64),
    layers.Dense(2, activation='softmax', name='softmax')
])

newnet.build(input_shape=(batch_size, 95))
newnet.summary()

newnet.compile(optimizer=optimizers.Adam(lr=1e-3), loss='categorical_crossentropy', metrics=['accuracy'])
newnet.fit(db_train, validation_data=db_val, validation_freq=10, epochs=epoch, callbacks=[TensorBoard(log_dir='log/',
    histogram_freq=1)])
newnet.evaluate(db_val)
newnet.save(model_name)
