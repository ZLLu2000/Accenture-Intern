import csv
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np


def normalize(data):
    min_value = min(data)
    max_value = max(data)
    new_list = []
    for i in data:
        new_list.append((i - min_value) / (max_value - min_value))
    return new_list


file = open("train.csv")
reader = csv.reader(file)
header_row = next(reader)
operating_expense, research_expense = [], []
operating_expense_0, research_expense_0 = [], []
operating_expense_1, research_expense_1 = [], []
label = []

for row in reader:
    label.append(row[0])
    operating_expense.append(float(row[11]))
    research_expense.append(float(row[12]))

operating_expense = normalize(operating_expense)
research_expense = normalize(research_expense)
label = label

for i in range(len(label)):
    if label[i] == "0":
        operating_expense_0.append(operating_expense[i]), research_expense_0.append(research_expense[i])
    else:
        operating_expense_1.append(operating_expense[i]), research_expense_1.append(research_expense[i])

ax = plt.subplot()
ax.set_title('expense rate 2D Scatter Map')  # 设置本图名称
ax.scatter(np.array(operating_expense_0), np.array(research_expense_0), c='b')
ax.scatter(np.array(operating_expense_1), np.array(research_expense_1), c='r')

ax.set_xlabel('Operating Expense Rate')  # 设置x坐标轴
ax.set_ylabel('Research and development expense rate')  # 设置y坐标轴
plt.savefig('expense.png')

