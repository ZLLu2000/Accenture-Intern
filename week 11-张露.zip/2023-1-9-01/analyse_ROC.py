import csv
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np


def normallize(data):
    min_value = min(data)
    max_value = max(data)
    new_list = []
    for i in data:
        new_list.append((i - min_value) / (max_value - min_value))
    return new_list


file = open("train.csv")
reader = csv.reader(file)
header_row = next(reader)
ROC_C, ROC_A, ROC_B = [], [], []
ROC_C_0, ROC_A_0, ROC_B_0 = [], [], []
ROC_C_1, ROC_A_1, ROC_B_1 = [], [], []
label = []

for row in reader:
    label.append(row[0])
    ROC_C.append(float(row[1]))
    ROC_A.append(float(row[2]))
    ROC_B.append(float(row[3]))

ROC_C = normallize(ROC_C)
ROC_A = normallize(ROC_A)
ROC_B = normallize(ROC_B)
label = label

for i in range(len(label)):
    if label[i] == "0":
        ROC_C_0.append(ROC_C[i]), ROC_A_0.append(ROC_A[i]), ROC_B_0.append(ROC_B[i])
    else:
        ROC_C_1.append(ROC_C[i]), ROC_A_1.append(ROC_A[i]), ROC_B_1.append(ROC_B[i])

ax = plt.subplot(projection='3d')  # 创建一个三维的绘图工程
ax.set_title('ROA 3D Scatter Map')  # 设置本图名称
ax.scatter(np.array(ROC_C_0), np.array(ROC_A_0), np.array(ROC_B_0), c='b')
ax.scatter(np.array(ROC_C_1), np.array(ROC_A_1), np.array(ROC_B_1), c='r')

ax.set_xlabel('ROA_C')  # 设置x坐标轴
ax.set_ylabel('ROA_A')  # 设置y坐标轴
ax.set_zlabel('ROA_B')  # 设置z坐标轴
plt.savefig('ROC.png')

