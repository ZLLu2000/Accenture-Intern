import csv
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np


def normalize(data):
    min_value = min(data)
    max_value = max(data)
    new_list = []
    for i in data:
        new_list.append((i - min_value) / (max_value - min_value))
    return new_list


file = open("train.csv")
reader = csv.reader(file)
header_row = next(reader)
asset_turnover, cash_turnover = [], []
asset_turnover_0, cash_turnover_0 = [], []
asset_turnover_1, cash_turnover_1 = [], []
label = []

for row in reader:
    label.append(row[0])
    asset_turnover.append(float(row[72]))
    cash_turnover.append(float(row[74]))

asset_turnover = normalize(asset_turnover)
cash_turnover = normalize(cash_turnover)

for i in range(len(label)):
    if label[i] == "0":
        asset_turnover_0.append(asset_turnover[i]), cash_turnover_0.append(cash_turnover[i])
    else:
        asset_turnover_1.append(asset_turnover[i]), cash_turnover_1.append(cash_turnover[i])

ax = plt.subplot()
ax.set_title('Turnover Rate')  # 设置本图名称
ax.scatter(np.array(asset_turnover_0), np.array(cash_turnover_0), c='b')
ax.scatter(np.array(asset_turnover_1), np.array(cash_turnover_1), c='r')

ax.set_xlabel('Current Asset Turnover Rate')  # 设置x坐标轴
ax.set_ylabel('Working capitcal Turnover Rate')  # 设置y坐标轴
plt.savefig('turnover.png')
