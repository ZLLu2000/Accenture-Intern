# coding=utf-8
import cv2
import tensorflow as tf
import csv
import os
from tensorflow.keras.preprocessing import image
from tensorflow.keras.models import load_model
import numpy as np
import pandas as pd
from keras.optimizers import Adam
from scipy import misc


def load_csv(root, csv_name):
    index, images = [], []
    with open(os.path.join(root, csv_name), 'r', encoding='utf8') as f:
        reader = csv.reader(f)
        for row in reader:
            if row[1] == 'id':
                continue
            index.append(int(row[0]))
            data = list(map(float, row[2:]))
            images.append(data)
    return index, images

def load_csv_normalize(root, csv_name):
    pa_csv = pd.read_csv(os.path.join(root, csv_name))
    pa_csv['obj_ID'] = (pa_csv['obj_ID'] - pa_csv['obj_ID'].min()) / (pa_csv['obj_ID'].max() - pa_csv['obj_ID'].min())
    pa_csv['alpha'] = (pa_csv['alpha'] - pa_csv['alpha'].min()) / (pa_csv['alpha'].max() - pa_csv['alpha'].min())
    pa_csv['delta'] = (pa_csv['delta'] - pa_csv['delta'].min()) / (pa_csv['delta'].max() - pa_csv['delta'].min())
    pa_csv['u'] = (pa_csv['u'] - pa_csv['u'].min()) / (pa_csv['u'].max() - pa_csv['u'].min())
    pa_csv['g'] = (pa_csv['g'] - pa_csv['g'].min()) / (pa_csv['g'].max() - pa_csv['g'].min())
    pa_csv['r'] = (pa_csv['r'] - pa_csv['r'].min()) / (pa_csv['r'].max() - pa_csv['r'].min())
    pa_csv['i'] = (pa_csv['i'] - pa_csv['i'].min()) / (pa_csv['i'].max() - pa_csv['i'].min())
    pa_csv['z'] = (pa_csv['z'] - pa_csv['z'].min()) / (pa_csv['z'].max() - pa_csv['z'].min())
    pa_csv['run_ID'] = (pa_csv['run_ID'] - pa_csv['run_ID'].min()) / (pa_csv['run_ID'].max() - pa_csv['run_ID'].min())
    pa_csv['cam_col'] = (pa_csv['cam_col'] - pa_csv['cam_col'].min()) / (pa_csv['cam_col'].max() - pa_csv['cam_col'].min())
    pa_csv['field_ID'] = (pa_csv['field_ID'] - pa_csv['field_ID'].min()) / (pa_csv['field_ID'].max() - pa_csv['field_ID'].min())
    pa_csv['spec_obj_ID'] = (pa_csv['spec_obj_ID'] - pa_csv['spec_obj_ID'].min()) / (pa_csv['spec_obj_ID'].max() - pa_csv['spec_obj_ID'].min())
    pa_csv['redshift'] = (pa_csv['redshift'] - pa_csv['redshift'].min()) / (pa_csv['redshift'].max() - pa_csv['redshift'].min())
    pa_csv['plate'] = (pa_csv['plate'] - pa_csv['plate'].min()) / (pa_csv['plate'].max() - pa_csv['plate'].min())
    pa_csv['MJD'] = (pa_csv['MJD'] - pa_csv['MJD'].min()) / (pa_csv['MJD'].max() - pa_csv['MJD'].min())
    pa_csv['fiber_ID'] = (pa_csv['fiber_ID'] - pa_csv['fiber_ID'].min()) / (pa_csv['fiber_ID'].max() - pa_csv['fiber_ID'].min())
    pa_csv.to_csv((os.path.join(root, "test_temp.csv")), mode='a', header=False)

def ImageEncode(item):
    x = np.array(item)
    x = np.expand_dims(x, axis=0)
    return x

root = "/home/zhangzifan/MaintoCode/2023-1-5-01"
model_path = 'final.h5'
test_csv_path = 'test.csv'

model = load_model(os.path.join(root, model_path))
load_csv_normalize(root, test_csv_path)
index, images = load_csv(root, "test_temp.csv")

result_index, result_label = [], []
for i in range(len(images[0:10])):
    code = ImageEncode(images[i])
    ret = model.predict(code)
    classes = np.argmax(ret[0, :])
    result_index.append(index[i])
    result_label.append(classes)

#字典中的key值即为csv中列名
dataframe = pd.DataFrame({'id': result_index, 'pred_label': result_label})
#将DataFrame存储为csv
dataframe.to_csv((os.path.join(root, "pred.csv")), index=False)


